if angelsmods.refining then
	require("prototypes.refining-override")
	require("prototypes.refining-generate")
end

-- EXECUTE OVERRIDES
angelsmods.functions.OV.execute()