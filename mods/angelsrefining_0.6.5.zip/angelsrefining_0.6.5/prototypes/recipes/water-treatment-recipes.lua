data:extend(
{
	{
    type = "recipe",
    name = "water-mineralized",
    category = "liquifying",
	subgroup = "water-treatment",
    energy_required = 1,
	enabled = "false",
    ingredients ={
      {type="fluid", name="water", amount=10},
	  {type="item", name="stone-crushed", amount=10},
	},
    results=
    {
      {type="fluid", name="water-mineralized", amount=10},
    },
    icon = "__angelsrefining__/graphics/icons/water-mineralized.png",
    order = "a[water-water-mineralized]",
	},
	{
    type = "recipe",
    name = "water-purification",
    category = "water-treatment",
	subgroup = "water-treatment",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water", amount=15}
	},
    results=
    {
      {type="fluid", name="water-saline", amount=2},
      {type="fluid", name="water-purified", amount=10},
    },
    icon = "__angelsrefining__/graphics/icons/water-purification.png",
    order = "b[water-purification]",
	},
	{
    type = "recipe",
    name = "thermal-water-purification",
    category = "water-treatment",
	subgroup = "water-treatment",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="thermal-water", amount=5}
	},
    results=
    {
      {type="fluid", name="mineral-sludge", amount=2},
      {type="fluid", name="water-purified", amount=3},
    },
    icon = "__angelsrefining__/graphics/icons/water-thermal-purification.png",
    order = "c[thermal-water-purification]",
	},
	--WASTE WATER TREATMENT
	{
    type = "recipe",
    name = "yellow-waste-water-purification",
    category = "water-treatment",
	subgroup = "water-cleaning",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water-yellow-waste", amount=10}
	},
    results=
    {
      {type="fluid", name="water-mineralized", amount=2},
      {type="fluid", name="water-purified", amount=7},
	  {type="item", name="sulfur", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/water-yellow-waste-purification.png",
    order = "d[yellow-waste-water-purification]",
	},
	{
    type = "recipe",
    name = "red-waste-water-purification",
    category = "water-treatment",
	subgroup = "water-cleaning",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water-red-waste", amount=10}
	},
    results=
    {
      {type="fluid", name="water-mineralized", amount=2},
      {type="fluid", name="water-purified", amount=7},
    },
    icon = "__angelsrefining__/graphics/icons/water-red-waste-purification.png",
    order = "e[yellow-waste-water-purification]",
	},
	{
    type = "recipe",
    name = "green-waste-water-purification",
    category = "water-treatment",
	subgroup = "water-cleaning",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water-green-waste", amount=10}
	},
    results=
    {
      {type="fluid", name="water-saline", amount=2},
      {type="fluid", name="water-purified", amount=7},
    },
    icon = "__angelsrefining__/graphics/icons/water-green-waste-purification.png",
    order = "f[yellow-waste-water-purification]",
	},
	{
    type = "recipe",
    name = "greenyellow-waste-water-purification",
    category = "water-treatment",
	subgroup = "water-cleaning",
    energy_required = 1,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water-greenyellow-waste", amount=10}
	},
    results=
    {
      {type="fluid", name="water-mineralized", amount=2},
      {type="fluid", name="water-purified", amount=7},
	  --{type="item", name="fluorite-ore", amount=1},
    },
    icon = "__angelsrefining__/graphics/icons/water-greenyellow-waste-purification.png",
    order = "g[yellow-waste-water-purification]",
	},
--SALINATION
	{
    type = "recipe",
    name = "water-saline",
    category = "salination-plant",
	subgroup = "water-salination",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water", amount=100}
	},
    results=
    {
      {type="fluid", name="water-saline", amount=40},
    },
    icon = "__angelsrefining__/graphics/icons/water-saline.png",
    order = "a[water-saline]",
	},
	{
    type = "recipe",
    name = "solid-salt-from-saline",
    category = "salination-plant",
	subgroup = "water-salination",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water-saline", amount=100}
	},
    results=
    {
		{type="item", name="solid-salt", amount=25},
    },
    --icon = "__angelspetrochem__/graphics/icons/solid-salt.png",
    order = "b[solid-salt-from-saline]",
	},
	{
    type = "recipe",
    name = "solid-salt",
    category = "salination-plant",
	subgroup = "water-salination",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{type="fluid", name="water", amount=100}
	},
    results=
    {
		{type="item", name="solid-salt", amount=10},
    },
    --icon = "__angelspetrochem__/graphics/icons/solid-salt.png",
    order = "c[solid-salt]",
	},
	{
    type = "recipe",
    name = "solid-lithium",
    category = "salination-plant",
	subgroup = "water-salination",
    energy_required = 10,
	enabled = "false",
    ingredients ={
	{type="fluid", name="thermal-water", amount=100}
	},
    results=
    {
		{type="item", name="solid-lithium", amount=20},
    },
    --icon = "__angelspetrochem__/graphics/icons/solid-lithium.png",
    order = "d[solid-lithium]",
	},
}
)