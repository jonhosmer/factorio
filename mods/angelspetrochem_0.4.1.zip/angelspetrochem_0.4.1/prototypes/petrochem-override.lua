--PREPARATIONS
angelsmods.functions.OV.remove_input("gas-sulfur-dioxide-calcium-sulfate", "angels-void")	

--CONFIG OPTIONs   
if angelsmods.petrochem.hideconverter then
   angelsmods.functions.OV.hide_recipe({
   "converter-sulfuric-acid",
   "converter-angels-sulfuric-acid",
   "liquid-heavy-oil",
   "liquid-light-oil",
   "liquid-petroleum-gas"
   })
   if bobmods.plates then
      angelsmods.functions.OV.hide_recipe({
      "converter-bob-chlorine",
      "converter-angels-chlorine",
      "converter-bob-oxygen",
      "converter-angels-oxygen",
      "converter-bob-hydrogen",
      "converter-angels-hydrogen",
      "converter-bob-hydrogen-chloride",
      "converter-angels-hydrogen-chloride",
      "converter-bob-nitrogen",
      "converter-angels-nitrogen",
      "converter-bob-sulfur-dioxide",
      "converter-angels-sulfur-dioxide"
      })
   end
end
	
if angelsmods.components then

else if bobmods.plates then
	require("prototypes.recipes.petrochem-entity-bob")
	
	angelsmods.functions.OV.set_input("catalyst-metal-green", "bauxite-ore", "item", 1)
	angelsmods.functions.OV.set_input("catalyst-metal-green", "silver-ore", "item", 1)
	angelsmods.functions.OV.set_input("catalyst-metal-blue", "rutile-ore", "item", 1)
	angelsmods.functions.OV.set_input("catalyst-metal-blue", "cobalt-ore", "item", 1)
	angelsmods.functions.OV.set_input("catalyst-metal-yellow", "tungsten-ore", "item", 1)
	angelsmods.functions.OV.set_input("catalyst-metal-yellow", "nickel-ore", "item", 1)
	
	angelsmods.functions.OV.set_input("gas-sulfur-dioxide-calcium-sulfate", "quartz", "item", 1)
	end
end