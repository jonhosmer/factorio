-- local config = require("config")

require("prototypes/buildings/tunnel")

require("prototypes/tile/fillableDirt")

require("prototypes/enemies/suicideBiters")
require("prototypes/enemies/fireSpitters")
