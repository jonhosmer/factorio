local tunnelUtils = {}

function tunnelUtils.digTunnel(regionMap, surface, natives, startChunk, endChunk)
    
end

function tunnelUtils.fillTunnel(regionMap, surface, natives, tilePositions)
    local tunnels = natives.tunnels
    for i=1, #tunnels do
        
    end
end

return tunnelUtils