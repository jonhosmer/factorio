note_slot_count = 51 -- maximum size of a note's internal storage. maximum allowed note length is (note_slot_count-1)*4-1.
autohide_time = 180 -- time to auto-hide sticky note in ticks (180 = 3sec)
text_color_default = {r=1,g=1,b=0} -- default text color
mapmark_default = false -- set to true if you want this option to be set by default
-- text_default = "default text" -- uncomment and define this value to overide default text

use_color_picker = true -- Color Picker mod (by Mooncat) will be used for changing the font color (if it has been installed separately).

