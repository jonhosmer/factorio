default_gui = data.raw["gui-style"].default

spacing_right = 2
spacing_vertical = 1
icon_height = 30
icon_width = 28
--frame_list_height = 18 + 33 * lines_per_page
frame_list_height = 40 + (30+spacing_vertical) * lines_per_page
frame_edit_height = 220
rights_width = 65


data:extend(
	{
		{
			type = "font",
			name = "spbook_font",
			from = "default",
			-- border = false,
			size = 15,
		},
		{
			type = "font",
			name = "spbook_font_bold",
			from = "default-bold",
			-- border = false,
			size = 15,
		},
		{
			type = "font",
			name = "spbook_font_title",
			from = "default-bold",
			-- border = false,
			size = 18,
		},
		{
			type = "font",
			name = "spbook_font_name",
			from = "default-bold",
			-- border = false,
			size = 15,
		},
		{
			type = "font",
			name = "spbook_font_xy",
			from = "default",
			-- border = false,
			size = 14,
		},
		{
			type = "font",
			name = "spbook_font_small",
			from = "default-bold",
			-- border = false,
			size = 13,
		},
	}
)

--------------------------------------------------------------------------------------
default_gui.spbook_frame_main_style = 
{
	type="frame_style",
	parent="frame_style",
	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	resize_row_to_width = true,
	resize_to_row_height = false,
    --minimal_width = 200,
}

default_gui.spbook_frame_style = 
{
	type="frame_style",
	parent="spbook_frame_main_style",
	resize_row_to_width = true,
	resize_to_row_height = false,
}

default_gui.spbook_frame_list_style = 
{
	type="frame_style",
	parent="spbook_frame_main_style",
	resize_row_to_width = true,
	resize_to_row_height = false,
	--minimal_width = 500,
	minimal_height = frame_list_height,
	maximal_height = frame_list_height,
}

default_gui.spbook_frame_edit_style = 
{
	type="frame_style",
	parent="spbook_frame_main_style",
	resize_row_to_width = true,
	resize_to_row_height = false,
	minimal_height = frame_edit_height,
	maximal_height = frame_edit_height,
}

--------------------------------------------------------------------------------------
default_gui.spbook_flow_style = 
{
	type = "flow_style",
	
	top_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	right_padding = 0,
	
	horizontal_spacing = spacing_right,
	vertical_spacing = spacing_vertical,
	max_on_row = 0,
	resize_row_to_width = true,
	resize_to_row_height = false,
	
	graphical_set = { type = "none" },
}

default_gui.spbook_flow_main_style = 
{
	type = "flow_style",
	parent = "spbook_flow_style",
	horizontal_spacing = 0,
	vertical_spacing = 0,
}

default_gui.spbook_flow_line_style = 
{
	type = "flow_style",
	parent = "spbook_flow_style",
}

--------------------------------------------------------------------------------------
default_gui.spbook_table_style =
{
	type = "table_style",
	horizontal_spacing = spacing_right,
	vertical_spacing = spacing_vertical,
	resize_to_row_height = false,
}

default_gui.spbook_label_style =
{
	type="label_style",
	parent="label_style",
	font="spbook_font",
	align = "left",
	default_font_color={r=1, g=1, b=1},
	hovered_font_color={r=1, g=1, b=1},
	top_padding = 1,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
}

default_gui.spbook_label_center_style =
{
	type="label_style",
	parent="spbook_label_style",
	font="spbook_font_bold",
	align = "center",
	minimal_width = 110,
	right_padding = 1,
}

default_gui.spbook_label_title_style =
{
	type="label_style",
	parent="spbook_label_style",
	font="spbook_font_title",
	align = "left",
	right_padding = 1,
}

default_gui.spbook_textfield_style =
{
    type = "textfield_style",
	font="spbook_font_bold",
	align = "left",
    font_color = {},
	default_font_color={r=1, g=1, b=1},
	hovered_font_color={r=1, g=1, b=1},
    selection_background_color= {r=0.66, g=0.7, b=0.83},
	top_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	right_padding = spacing_right,
	minimal_width = 110,
	--maximal_width = 110,
	graphical_set =
	{
		type = "composition",
		filename = "__core__/graphics/gui.png",
		priority = "extra-high-no-scale",
		corner_size = {3, 3},
		position = {16, 0}
	},
}    

default_gui.spbook_textfield_rgb_style =
{
    type = "textfield_style",
	parent="spbook_textfield_style",
	font="spbook_font",
	minimal_width = 35,
	--maximal_width = 110,
	graphical_set =
	{
		type = "composition",
		filename = "__core__/graphics/gui.png",
		priority = "extra-high-no-scale",
		corner_size = {3, 3},
		position = {16, 0}
	},
}    

default_gui.spbook_checkbox_style =
{
	type = "checkbox_style",
	font = "spbook_font_small",
	font_color = {r=1, g=1, b=1},
	top_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	right_padding = spacing_right,
	minimal_height = icon_height,
	maximal_height = icon_height-2,
	default_background =
	{
		filename = "__core__/graphics/gui.png",
		priority = "extra-high-no-scale",
		width = 16,
		height = 16,
		x = 43,
		y = 17
	},
	hovered_background =
	{
		filename = "__core__/graphics/gui.png",
		priority = "extra-high-no-scale",
		width = 16,
		height = 16,
		x = 60,
		y = 17
	},
	clicked_background =
	{
		filename = "__core__/graphics/gui.png",
		priority = "extra-high-no-scale",
		width = 16,
		height = 16,
		x = 77,
		y = 17
	},
	checked =
	{
		filename = "__core__/graphics/gui.png",
		priority = "extra-high-no-scale",
		width = 16,
		height = 16,
		x = 94,
		y = 17
	}
}