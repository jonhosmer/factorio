confirm_timeout = 3 -- time to confirm deletion in seconds
info_timeout = 5 -- time to confirm deletion in seconds
message_banned_timeout = 10 -- time between message to banned player, asking him to leave
password_timeout = 10 -- time to warn user with empty password in seconds
autojoin_delay = 120 -- delay before potential autojoin of guests members in seconds

lines_per_page = 6 -- lines per page in the forces/players list view

guest_force_name = "guests" -- name of the guests force where incoming players are affected

admin_speed_factor = 10 -- multiplier for the admin avatar speed
admin_zoom = 0.05 -- wide zoom for admin (don't go too far...)

tool_ore_min_amount = 1000 -- minimum ore revealed by a dynamite
tool_ore_max_amount = 2000 -- maximum ore revealed by a dynamite
tool_oil_min_yield = 300 -- minimum oil revealed by a dynamite
tool_oil_max_yield = 600 -- maximum oil revealed by a dynamite
