require("utils")
require("config")

require("prototypes.styles")
require("prototypes.styles_buttons")
require("prototypes.adminanims")
require("prototypes.admin")

data:extend(
	{
		{
			-- https://wiki.factorio.com/index.php?title=Prototype/SelectionTool
			type = "selection-tool",
			name = "spacebook-tool",
			icon = "__SpaceBook__/graphics/spacebook-tool.png",
			flags = {"goes-to-quickbar"},
			subgroup = "tool",
			order = "c[automated-construction]-z",
			stack_size = 1,
			stackable = false,
			draw_label_for_cursor_render = true,
			-- copy mode :
			alt_selection_mode = {"tiles"},
			alt_selection_color = { r = 0, g = 1, b = 0 },
			alt_selection_cursor_box_type = "copy",
			-- paste mode :
			-- selection_mode = {"matches-force", "buildable-type"},
			selection_mode = {"tiles"},
			selection_color = { r = 1, g = 1, b = 0 },
			selection_cursor_box_type = "copy",
			always_include_tiles = false,
		},
		
		{
			type = "recipe",
			name = "spacebook-tool",
			energy_required = 0.1,
			enabled = "true",
			ingredients = {},
			result = "spacebook-tool",
		}
	}
)
