data:extend(
{
  {
    type = "noise-layer",
    name = "fluorite"
  },
  {
    type = "noise-layer",
    name = "uraninite"
  },
}
)
