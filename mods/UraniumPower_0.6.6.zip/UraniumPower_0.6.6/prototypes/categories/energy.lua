data:extend(
{
	{
		type = "item-subgroup",
		name = "uranium-energy-pipe-distribution", --pumps and stuff
		group = "uranium",
		order = "b",
	},
		{
		type = "item-subgroup",
		name = "uranium-energy-conversion", --steam generators, turbine generators, condensers, cooling towers
		group = "uranium",
		order = "c",
	}
})