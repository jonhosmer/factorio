local hotkeys = {}
local function addHotkey(name, key_sequence)
    table.insert(hotkeys, {
        type = "custom-input",
        name = name,
        key_sequence = key_sequence,
        consuming = "script-only"
    })
end
addHotkey("cursorlock-toggle", "SHIFT + F")
data:extend(hotkeys)
