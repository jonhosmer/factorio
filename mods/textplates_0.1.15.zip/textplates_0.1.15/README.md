# factorio-textplates
Factorio Text Plates Mod
Source: https://github.com/earendelentertainment/factorio-textplates

New features and updates go in a new branch with the naming convention:
updates/[version branched off]_[feature title]
eg:
updates/0.1.8_paintedtext

bugfixes go in a new branch with the naming convention:
updates/[version branched off]_[bug title]
eg:
fixes/0.1.8_get_control_is_nil

When something is ready merge the working branch in to develop to test with any other updates. 
If that works then merge the working branch into master.
