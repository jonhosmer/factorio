-- not local for this phase
textplates = require("plate-types")

require("prototype.styles")
require("prototype.item-groups")

require("prototype.entity.entity")
require("prototype.recipe.recipe")
require("prototype.item.item")