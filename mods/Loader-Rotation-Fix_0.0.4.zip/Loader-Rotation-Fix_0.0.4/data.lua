    data:extend(
    	{
    		{
    			type = "custom-input",
    			name = "lrf-toggle",
    			key_sequence = "CONTROL + L",
    			consuming = "script-only"
    	  },
    	}
    )
