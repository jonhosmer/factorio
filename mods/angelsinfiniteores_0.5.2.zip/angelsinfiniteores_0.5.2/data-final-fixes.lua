if angelsmods.refining then
	require("prototypes.generation.angels-override")
end