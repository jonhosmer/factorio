data:extend(
{
  {
    type = "simple-entity",
    name = "angels-crystal-rock",
    flags = {"placeable-neutral", "placeable-off-grid", "not-on-map"},
    icon = "__base__/graphics/icons/stone-rock.png",
    subgroup = "grass",
    order = "b[decorative]-k[stone-rock]-c[crystal]",
    collision_box = {{-1.1, -1.1}, {1.1, 1.1}},
    selection_box = {{-1.3, -1.3}, {1.3, 1.3}},
    minable =
    {
      mining_particle = "stone-particle",
      mining_time = 8,
      result = "stone",
      count = 20
    },
    loot =
    {
      {item = "stone", probability = 1, count_min = 5, count_max = 10}
    },
    mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
    render_layer = "object",
    max_health = 200,
    resistances =
    {
      {
        type = "fire",
        percent = 100
      }
    },
    autoplace =
    {
      order = "a[doodad]-c[angels-crystal-rock]",
      max_probability = 0.05,
      peaks =
      {
        {
          influence = 0.0002
        },
        {
          influence = 0.002;
          min_influence = 0,
          elevation_optimal = 45000,
          elevation_range = 37000,
          elevation_max_range = 45000,
        }
      }
    },
    pictures =
    {
      {
        filename = "__angelsinfiniteores__/graphics/entity/rock/crystal-rock-1.png",
        width = 192,
        height = 160,
        shift = {0.5, 0}
      },
      {
        filename = "__angelsinfiniteores__/graphics/entity/rock/crystal-rock-2.png",
        width = 192,
        height = 160,
        shift = {0.5, 0}
      },
      {
        filename = "__angelsinfiniteores__/graphics/entity/rock/crystal-rock-3.png",
        width = 192,
        height = 160,
        shift = {0.5, 0}
      },
      {
        filename = "__angelsinfiniteores__/graphics/entity/rock/crystal-rock-4.png",
        width = 192,
        height = 160,
        shift = {0.5, 0}
      },
    }
  },
})
