data:extend(
	{
		{
			type = "font",
			name = "score_font",
			from = "default",
			border = false,
			size = 15
		},
		{
			type = "font",
			name = "score_font_bold",
			from = "default-bold",
			border = false,
			size = 15
		},
		{
			type = "font",
			name = "score_font_small",
			from = "default",
			border = false,
			size = 13
		},

		{
			type = "sprite",
			name = "sprite_rocket_on",
			filename = "__ScoreExtended__/graphics/but-on.png",
			width = 22,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_rocket_off",
			filename = "__ScoreExtended__/graphics/but-off.png",
			width = 22,
			height = 30,
		},
	}
)		

--------------------------------------------------------------------------------------
local default_gui = data.raw["gui-style"].default

default_gui.score_frame_style = 
{
	type="frame_style",
	parent="frame_style",
	font="score_font_bold",
	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	resize_row_to_width = true,
	resize_to_row_height = false,
	-- max_on_row = 1,
}

default_gui.score_flow_style = 
{
	type = "flow_style",
	
	top_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	right_padding = 0,
	
	horizontal_spacing = 2,
	vertical_spacing = 0,
	resize_row_to_width = true,
	resize_to_row_height = false,
	max_on_row = 1,
	
	graphical_set = { type = "none" },
}

--------------------------------------------------------------------------------------
default_gui.score_label_style =
{
	type="label_style",
	parent="label_style",
	font="score_font",
	align = "left",
	default_font_color={r=1, g=1, b=1},
	hovered_font_color={r=1, g=1, b=1},
	top_padding = 0,
	right_padding = 1,
	bottom_padding = 0,
	left_padding = 1,
}

default_gui.score_label_small_style =
{
	type="label_style",
	parent="score_label_style",
	font="score_font_small",
	default_font_color={r=1, g=1, b=0.5},
	hovered_font_color={r=1, g=1, b=0.5},
}

default_gui.score_label_title_style =
{
	type="label_style",
	parent="score_label_style",
	font="score_font_bold",
	default_font_color={r=1, g=1, b=0.5},
	hovered_font_color={r=1, g=1, b=0.5},
}

default_gui.score_button_style = 
{
	type="button_style",
	parent="button_style",
	font="score_font_bold",
	align = "center",
	default_font_color={r=1, g=1, b=1},
	hovered_font_color={r=1, g=1, b=1},
	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	left_click_sound =
	{
		{
		  filename = "__core__/sound/gui-click.ogg",
		  volume = 1
		}
	},
}

default_gui.score_button_small_style = 
{
	type="button_style",
	parent="button_style",
	font="score_font_small",
	align = "center",
	default_font_color={r=1, g=1, b=1},
	hovered_font_color={r=1, g=1, b=1},
	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	left_click_sound =
	{
		{
		  filename = "__core__/sound/gui-click.ogg",
		  volume = 1
		}
	},
}

default_gui.score_checkbox_style =
{
	type = "checkbox_style",
	parent="checkbox_style",
	font = "score_font_small",
	font_color = {r=1, g=1, b=1},
	top_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	right_padding = 2,
	-- minimal_height = 32,
	-- maximal_height = 32,
}


default_gui.score_button_rocket_off_style = 
{
    type = "button_style",
	parent="slot_button_style",

	scalable = false,

	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,

	width = 23,
	height = 30,

	default_graphical_set = extract_monolith("__ScoreExtended__/graphics/gui.png", 0, 0, 23, 30),
	hovered_graphical_set = extract_monolith("__ScoreExtended__/graphics/gui.png", 23, 0, 23, 30),
	clicked_graphical_set = extract_monolith("__ScoreExtended__/graphics/gui.png", 46, 0, 23, 30),
}

default_gui.score_button_rocket_on_style = 
{
    type = "button_style",
	parent="slot_button_style",

	scalable = false,

	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,

	width = 23,
	height = 30,

	default_graphical_set = extract_monolith("__ScoreExtended__/graphics/gui.png", 0, 30, 23, 30),
	hovered_graphical_set = extract_monolith("__ScoreExtended__/graphics/gui.png", 23, 30, 23, 30),
	clicked_graphical_set = extract_monolith("__ScoreExtended__/graphics/gui.png", 46, 30, 23, 30),
}

default_gui.score_sprite_style = 
{
	type="button_style",
	parent="button_style",
	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	width = 28,
	height = 36,
	scalable = false,
}

