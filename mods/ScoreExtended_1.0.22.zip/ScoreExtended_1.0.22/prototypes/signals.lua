data:extend(
	{
		{
			type = "item-subgroup",
			name = "virtual-signal-score",
			group = "signals",
			order = "x[virtual-signal-score]"
		},
		
		{
			type = "virtual-signal",
			name = "signal-score-rockets-tot",
			icon = "__ScoreExtended__/graphics/signal-score-rockets-tot.png",
			subgroup = "virtual-signal-score",
			order = "y[score]-aa"
		},
		{
			type = "virtual-signal",
			name = "signal-score-rockets-cnt",
			icon = "__ScoreExtended__/graphics/signal-score-rockets-cnt.png",
			subgroup = "virtual-signal-score",
			order = "y[score]-ab"
		},

		{
			type = "virtual-signal",
			name = "signal-score-rockets-rph",
			icon = "__ScoreExtended__/graphics/signal-score-rockets-rph.png",
			subgroup = "virtual-signal-score",
			order = "y[score]-ba"
		},
		{
			type = "virtual-signal",
			name = "signal-score-rockets-rpm",
			icon = "__ScoreExtended__/graphics/signal-score-rockets-rpm.png",
			subgroup = "virtual-signal-score",
			order = "y[score]-bb"
		},
		
		{
			type = "virtual-signal",
			name = "signal-score-rockets-mpr",
			icon = "__ScoreExtended__/graphics/signal-score-rockets-mpr.png",
			subgroup = "virtual-signal-score",
			order = "y[score]-ca"
		},
		{
			type = "virtual-signal",
			name = "signal-score-rockets-spr",
			icon = "__ScoreExtended__/graphics/signal-score-rockets-spr.png",
			subgroup = "virtual-signal-score",
			order = "y[score]-cb"
		},

	}
)
