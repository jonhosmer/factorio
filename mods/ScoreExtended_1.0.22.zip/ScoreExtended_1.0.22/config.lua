score_delay = 8 -- delay in seconds before hiding rocket score window (0 = never show)
autolaunch_default = false -- default autolaunch option
unit_change_rocket_per_hour = 60
default_precision = 1