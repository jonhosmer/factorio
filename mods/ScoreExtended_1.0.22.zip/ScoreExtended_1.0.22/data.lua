require("utils")
require("prototypes/styles")
require("prototypes/signals")


local combi = dupli_proto("constant-combinator","constant-combinator","rocket-combinator")
combi.icon = "__ScoreExtended__/graphics/rocket-combinator-icon.png"
combi.sprites =
	{
		north =
		{
			filename = "__ScoreExtended__/graphics/rocket-combinator.png",
			x = 61,
			width = 61,
			height = 50,
			shift = {0.078125, 0.15625},
		},
		east =
		{
			filename = "__ScoreExtended__/graphics/rocket-combinator.png",
			x = 61,
			width = 61,
			height = 50,
			shift = {0.078125, 0.15625},
		},
		south =
		{
			filename = "__ScoreExtended__/graphics/rocket-combinator.png",
			x = 61,
			width = 61,
			height = 50,
			shift = {0.078125, 0.15625},
		},
		west =
		{
			filename = "__ScoreExtended__/graphics/rocket-combinator.png",
			x = 61,
			width = 61,
			height = 50,
			shift = {0.078125, 0.15625},
		},
	}
combi.item_slot_count = 6

data:extend(
	{
		combi,
		
		----------------------------------------------------------------------------------
		{
			type = "item",
			name = "rocket-combinator",
			icon = "__ScoreExtended__/graphics/rocket-combinator-icon.png",
			flags = { "goes-to-quickbar" },
			subgroup = "circuit-network",
			place_result="rocket-combinator",
			order = "b[combinators]-r[rocket-combinator]",
			stack_size= 50,
		},
		
		---------------------------------------------------------------------------------
		{
			type = "recipe",
			name = "rocket-combinator",
			enabled = "false",
			ingredients =
			{
				{"copper-cable", 5},
				{"electronic-circuit", 2},
			},
			result = "rocket-combinator"
		},
	}
)

table.insert( data.raw["technology"]["circuit-network"].effects, { type = "unlock-recipe", recipe = "rocket-combinator" } )

