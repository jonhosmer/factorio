require("prototypes.item")
require("prototypes.recipe")
require("prototypes.entity")
require("prototypes.technology")
data:extend({
  {
    type = "custom-input",
    name = "copy-loader-filters",
    key_sequence = "SHIFT + mouse-button-2"
  },
  {
    type = "custom-input",
    name = "paste-loader-filters",
    key_sequence = "SHIFT + mouse-button-1"
  }
})