function make_loader_item(name,order)
	local subgroup="belt"
	if string.find(name,"faster") or string.find(name,"extremely") then subgroup="bob-belt" end
	return{
		type="item",
		name=name,
		icon="__add-loader__/graphics/icons/"..name..".png",
		flags={"goes-to-quickbar"},
		subgroup=subgroup,
		order=order,
		place_result=name,
		stack_size=50
	}
end

data:extend({
make_loader_item("loader","d-a"),
make_loader_item("fast-loader","d-b"),
make_loader_item("express-loader","d-c"),
})

if data.raw["item"]["green-transport-belt"] then
data:extend({
make_loader_item("faster-loader","d-a"),
make_loader_item("extremely-fast-loader","d-a"),
})
end