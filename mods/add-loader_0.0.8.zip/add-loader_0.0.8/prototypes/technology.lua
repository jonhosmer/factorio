data:extend({
	{
    type = "technology",
    name = "loader",
    icon = "__base__/graphics/technology/logistics.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "loader"
      },
	 },
    prerequisites = {"logistics"},
    unit =
    {
      count = 30,
      ingredients =
      {
        {"science-pack-1", 1}
      },
      time = 15
    },
    order = "a-f-a",
	},
	{
    type = "technology",
    name = "fast-loader",
    icon = "__base__/graphics/technology/logistics.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fast-loader"
      },
	 },
    prerequisites = {"logistics-2"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 15
    },
    order = "a-f-b",
	},
	{
    type = "technology",
    name = "express-loader",
    icon = "__base__/graphics/technology/logistics.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "express-loader"
      },
	 },
    prerequisites = {"logistics-3"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 15
    },
    order = "a-f-c",
	},
})

if data.raw["item"]["green-transport-belt"] then
data:extend({
   {
    type = "technology",
    name = "faster-loader",
    icon = "__base__/graphics/technology/logistics.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "faster-loader"
      }
    },
    prerequisites = {"bob-logistics-4"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 20
    },
    order = "a-f-d",
  },
  {
    type = "technology",
    name = "extremely-fast-loader",
    icon = "__base__/graphics/technology/logistics.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "extremely-fast-loader"
      }
    },
    prerequisites = {"bob-logistics-5"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"alien-science-pack", 1}
      },
      time = 30
    },
    order = "a-f-e",
  },    
})
end