if data.raw["item"]["green-transport-belt"] then
data:extend({ 
	{
    type = "loader",
    name = "faster-loader",
    icon = "__add-loader__/graphics/icons/faster-loader.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "faster-loader"},
    max_health = 70,
    filter_count = 5,
    corpse = "small-remnants",
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
    collision_box = {{-0.4, -0.9}, {0.4, 0.9}},
    selection_box = {{-0.5, -1}, {0.5, 1}},
    animation_speed_coefficient = 32,
    belt_horizontal = green_belt_horizontal,
    belt_vertical = green_belt_vertical,
    ending_top = green_belt_ending_top,
    ending_bottom = green_belt_ending_bottom,
    ending_side = green_belt_ending_side,
    starting_top = green_belt_starting_top,
    starting_bottom = green_belt_starting_bottom,
    starting_side = green_belt_starting_side,
    fast_replaceable_group = "loader",
    speed = 0.125,
    structure =
    {
      direction_in =
      {
        sheet =
        {
          filename = "__add-loader__/graphics/entity/loader/faster-loader-structure.png",
          priority = "extra-high",
          width = 64,
          height = 64
        }
      },
      direction_out =
      {
        sheet =
        {
          filename = "__add-loader__/graphics/entity/loader/faster-loader-structure.png",
          priority = "extra-high",
          width = 64,
          height = 64,
          y = 64
        }
      }
    },
    ending_patch = ending_patch_prototype
  },
  {
    type = "loader",
    name = "extremely-fast-loader",
    icon = "__add-loader__/graphics/icons/extremely-fast-loader.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "extremely-fast-loader"},
    max_health = 70,
    filter_count = 5,
    corpse = "small-remnants",
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
    collision_box = {{-0.4, -0.9}, {0.4, 0.9}},
    selection_box = {{-0.5, -1}, {0.5, 1}},
    animation_speed_coefficient = 32,
    belt_horizontal = purple_belt_horizontal,
    belt_vertical = purple_belt_vertical,
    ending_top = purple_belt_ending_top,
    ending_bottom = purple_belt_ending_bottom,
    ending_side = purple_belt_ending_side,
    starting_top = purple_belt_starting_top,
    starting_bottom = purple_belt_starting_bottom,
    starting_side = purple_belt_starting_side,
    fast_replaceable_group = "loader",
    speed = 0.15625,
    structure =
    {
      direction_in =
      {
        sheet =
        {
          filename = "__add-loader__/graphics/entity/loader/extremely-fast-loader-structure.png",
          priority = "extra-high",
          width = 64,
          height = 64
        }
      },
      direction_out =
      {
        sheet =
        {
          filename = "__add-loader__/graphics/entity/loader/extremely-fast-loader-structure.png",
          priority = "extra-high",
          width = 64,
          height = 64,
          y = 64
        }
      }
    },
    ending_patch = ending_patch_prototype
  },
})
end
for a,b in pairs({"loader","fast-loader","express-loader"}) do
	if data.raw["loader"][b] then
		data.raw["loader"][b].structure.direction_in.sheet.filename="__add-loader__/graphics/entity/loader/"..b.."-structure.png"
		data.raw["loader"][b].structure.direction_out.sheet.filename="__add-loader__/graphics/entity/loader/"..b.."-structure.png"
		data.raw["loader"][b].icon = "__add-loader__/graphics/icons/"..b..".png"
		data.raw["loader"][b].flags = {"placeable-neutral", "player-creation"}
	end
end