if data.raw["item"]["green-transport-belt"] then
data:extend({
	{
    type = "recipe",
    name = "faster-loader",
    enabled = "false",
	 energy_required = 15,
    ingredients =
    {
      {"green-transport-belt", 5},
      {"express-loader", 1},
		{"green-splitter", 1}
    },
    result = "faster-loader"
   },
   {
    type = "recipe",
    name = "extremely-fast-loader",
    enabled = "false",
	 energy_required = 20,
    ingredients =
    {
      {"purple-transport-belt", 5},
      {"faster-loader", 1},
		{"purple-splitter", 1}
    },
    result = "extremely-fast-loader"
   },
})
end