require("prototypes.item.item")
require("prototypes.recipe.recipe")

bobmods = bobmods or {}
bobmods.lib = bobmods.lib or {}

require("item-functions")
require("recipe-functions")



local costMultiplier = 1
if NE_Expansion_Config ~= nil and NE_Expansion_Config.ScienceCost then
	costMultiplier = 2
end

local fix
fix = data.raw.technology["military-2"]
table.insert(fix.effects, {type = "unlock-recipe", recipe = "military-science-pack"})

fix = data.raw.technology["advanced-electronics"]
table.insert(fix.effects, {type = "unlock-recipe", recipe = "science-pack-3"})

fix = data.raw.technology["electric-engine"]
table.insert(fix.effects, {type = "unlock-recipe", recipe = "science-pack-4"})

fix = data.raw.recipe["advanced-circuit"]
fix.energy_required = 6

fix = data.raw.recipe["engine-unit"]
fix.energy_required = 10

fix = data.raw.recipe["electric-engine-unit"]
fix.energy_required = 10

fix = data.raw.recipe["pumpjack"]
fix.energy_required = 10

fix = data.raw.recipe["advanced-circuit"]
fix.energy_required = 6

fix = data.raw.recipe["electric-furnace"]
fix.ingredients = {{"steel-plate", 9}, {"advanced-circuit", 3}, {"stone-brick", 6}}


bobmods.lib.recipe.replace_ingredient("fusion-reactor-equipment", "alien-artifact", "alien-science-pack")
bobmods.lib.recipe.replace_ingredient("speed-module-3", "alien-artifact", "alien-science-pack")
bobmods.lib.recipe.replace_ingredient("productivity-module-3", "alien-artifact", "alien-science-pack")
bobmods.lib.recipe.replace_ingredient("effectivity-module-3", "alien-artifact", "alien-science-pack")
bobmods.lib.recipe.replace_ingredient("modular-armor", "alien-artifact", "alien-science-pack")
bobmods.lib.recipe.replace_ingredient("power-armor", "alien-artifact", "alien-science-pack")
bobmods.lib.recipe.replace_ingredient("power-armor-mk2", "alien-artifact", "alien-science-pack")



fix = data.raw.technology["battery"]
local temp = {}
for i,v in pairs(fix.effects) do
	if v.type == "unlock-recipe" and v.recipe ~= "science-pack-3" then
		table.insert(temp, v)
	end
end
fix.effects = temp



if data.raw.lab["lab-2"] == nil then
	-- Vanilla
	fix = data.raw.lab["lab"]
	fix.inputs = {
      "science-pack-1",
      "science-pack-2",
      "science-pack-3",
      "military-science-pack",
	  "science-pack-4",
	  "alien-science-pack",
    }
else
	-- Bobs
	fix = data.raw.lab["lab"]
	fix.inputs = {
      "science-pack-1",
      "science-pack-2",
      "science-pack-3",
      "military-science-pack",
    }
	
	fix = data.raw.lab["lab-2"]
	table.insert(fix.inputs, "military-science-pack")
end

fix = data.raw.lab["lab-alien"]
if fix ~= nil then
	table.insert(fix.inputs, "military-science-pack")
	table.insert(fix.inputs, "science-pack-4")
end

fix = data.raw.lab["replication-lab"]
if fix ~= nil then
	table.insert(fix.inputs, "military-science-pack")
	table.insert(fix.inputs, "science-pack-4")
end

fix = data.raw.recipe["science-pack-3"]
fix.ingredients =
    {
      {"advanced-circuit", costMultiplier},
      {"engine-unit", costMultiplier},
      {"assembling-machine-2", costMultiplier},
    }
	
fix = data.raw.tool["alien-science-pack"]
fix.icon = "__ResearchRevolution__/graphics/icons/high-tech-science-pack.png"

fix = data.raw.recipe["alien-science-pack"]
fix.icon = "__ResearchRevolution__/graphics/icons/high-tech-science-pack.png"
	
fix = data.raw.recipe["alien-science-pack"]
fix.ingredients =
    {
	  {"battery", costMultiplier},
      {"processing-unit", 3*costMultiplier},
      {"speed-module", costMultiplier},
      {"copper-cable", 30*costMultiplier},
    }
fix.result_count = 1
fix.energy_required = 15

fix = data.raw.recipe["military-science-pack"]
fix.ingredients =
    {
	  {"piercing-rounds-magazine", costMultiplier},
      {"grenade", costMultiplier},
      {"gun-turret", costMultiplier},
    }

fix = data.raw.recipe["science-pack-4"]
fix.icon = "__base__/graphics/icons/alien-science-pack.png"
if fix ~= nil then
	if data.raw.recipe["silicon-nitride"] and data.raw.recipe["lithium-ion-battery"] then
		fix.ingredients={{"pumpjack", costMultiplier}, {"electric-furnace", costMultiplier}}
		table.insert(fix.ingredients,{"silicon-nitride", costMultiplier})
		table.insert(fix.ingredients, {"lithium-ion-battery", costMultiplier})
	else
		-- Vanilla/No Bobs plates
		fix.ingredients={{"pumpjack", costMultiplier}, {"electric-engine-unit", costMultiplier}, {"electric-furnace", costMultiplier} }
	end
end

function recurseTech (searchTech, techType)
	for k, tech in pairs ( data.raw.technology) do
		if tech.prerequisites ~= nil then
			for i, prereq in pairs(tech.prerequisites) do
				if searchTech == prereq then
					local addPack = true
					for ii, pack in pairs(tech.unit.ingredients) do
						if pack[1] == techType or pack[1] == "module-case" or pack[1] == "speed-processor" or pack[1] == "effectivity-processor" or pack[1] == "productivity-processor" or pack[1] == "pollution-clean-processor" or pack[1] == "pollution-create-processor" then
							addPack = false
						end
					end
					if addPack == true then
						table.insert(tech.unit.ingredients, {techType, 1})
						recurseTech(tech.name, techType)
					end
				end
			end
		end
	end
end

local rootMilitaryTechs = {
"military-3",
"laser",
"flammables",
"gates",
"land-mine",
"grenade-damage-1",
"combat-robotics",
"gun-turret-damage-3",
"bullet-damage-3",
"bullet-speed-3",
"shotgun-shell-damage-3",
"shotgun-shell-speed-3",
}

for k, tech in pairs(rootMilitaryTechs) do
	local techType = "military-science-pack"
	local rootTech = data.raw.technology[tech]
	if rootTech ~= nil then
		local addPack = true
		for ii, pack in pairs(rootTech.unit.ingredients) do
			if pack[1] == techType then
				addPack = false
			end
		end
		if addPack == true then
			table.insert(rootTech.unit.ingredients, {techType, 1})
			recurseTech(rootTech.name, techType)
		end
	end
end


local rootProductionTechs = {
"advanced-electronics-2",
"modules",
"armor-making-3",
}




for k, tech in pairs(rootProductionTechs) do
	local techType = "science-pack-4"
	local rootTech = data.raw.technology[tech]
	if rootTech ~= nil then
		local addPack = true
		for ii, pack in pairs(rootTech.unit.ingredients) do
			if pack[1] == techType then
				addPack = false
			end
		end
		if addPack == true then
			table.insert(rootTech.unit.ingredients, {techType, 1})
			recurseTech(rootTech.name, techType)
		end
	end
end
