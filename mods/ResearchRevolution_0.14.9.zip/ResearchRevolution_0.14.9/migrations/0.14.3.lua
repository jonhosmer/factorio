-- Reset technologies and recipes
for i, player in ipairs(game.players) do
	player.force.reset_recipes()
	player.force.reset_technologies()
end

for i, force in pairs(game.forces) do 
	if force.technologies["military-2"].researched then 
		force.recipes["military-science-pack"].enabled = true
	end
	
	if force.technologies["advanced-electronics"].researched then 
		force.recipes["science-pack-4"].enabled = true
	end
end