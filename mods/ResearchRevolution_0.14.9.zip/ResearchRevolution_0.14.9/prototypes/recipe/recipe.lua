data:extend(
{
  {
    type = "recipe",
    name = "science-pack-4",
    enabled = "false",
    energy_required = 15,
    ingredients =
    {
	  {"electric-furnace", 1},
	  {"pumpjack", 1},
	},
    result = "science-pack-4"
  },
  {
    type = "recipe",
    name = "military-science-pack",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
	  {"piercing-rounds-magazine", 1},
      {"grenade", 1},
      {"gun-turret", 1},
    },
    result = "military-science-pack",
	result_count = 2
  },
}
)

