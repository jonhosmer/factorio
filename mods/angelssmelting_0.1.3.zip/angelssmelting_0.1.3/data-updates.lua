require("prototypes.angels-smelting-override")
	